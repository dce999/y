// server.js
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const mysql = require('mysql2');

const app = express();
const PORT = 3000;

// 设置 Body Parser 解析请求体
app.use(bodyParser.urlencoded({ extended: true }));

// 创建数据库连接
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '123456',
  database: 'material_management'
});

db.connect(err => {
  if (err) {
    console.error('数据库连接失败：', err);
    return;
  }
  console.log('数据库连接成功！');
});

// 将 public 文件夹设置为静态资源目录
app.use(express.static(path.join(__dirname, 'public')));

// 路由 - 首页
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// 路由 - 管理员登录
app.post('/login_admin', (req, res) => {
  const { username, password } = req.body;
  const query = `SELECT * FROM admins WHERE username = ? AND password = ?`;
  db.query(query, [username, password], (err, result) => {
    if (err) {
      return res.send('数据库查询失败');
    }
    if (result.length > 0) {
      res.redirect('/admin_dashboard.html');  // 重定向到管理员面板
    } else {
      res.send('用户名或密码错误');
    }
  });
});

// 路由 - 学生验证
app.post('/verify_student', (req, res) => {
  const { student_id } = req.body;
  const query = `SELECT * FROM students WHERE student_id = ?`;
  db.query(query, [student_id], (err, result) => {
    if (err) {
      return res.send('数据库查询失败');
    }
    if (result.length > 0) {
      res.redirect('/student_dashboard.html'); // 重定向到学生面板
    } else {
      res.send('无效学号');
    }
  });
});

// 管理员功能
app.post('/add_admin', (req, res) => {
  const { username, password } = req.body;
  const query = `INSERT INTO admins (username, password) VALUES (?, ?)`;
  db.query(query, [username, password], (err, result) => {
    if (err) {
      return res.send('添加管理员失败');
    }
    res.send('管理员添加成功');
  });
});

app.post('/delete_admin', (req, res) => {
  const { username } = req.body;
  const query = `DELETE FROM admins WHERE username = ?`;
  db.query(query, [username], (err, result) => {
    if (err) {
      return res.send('删除管理员失败');
    }
    res.send('管理员删除成功');
  });
});

app.post('/update_password', (req, res) => {
  const { username, password, targetUsername } = req.body;
  const query = `UPDATE admins SET password = ? WHERE username = ? OR username = ?`;
  db.query(query, [password, username, targetUsername], (err, result) => {
    if (err) {
      return res.send('更新密码失败');
    }
    res.send('密码更新成功');
  });
});

// 信息管理功能
app.post('/add_purchase_person', (req, res) => {
  const { name, department, contact } = req.body;
  const query = `INSERT INTO purchase_persons (name, department, contact) VALUES (?, ?, ?)`;
  db.query(query, [name, department, contact], (err, result) => {
    if (err) {
      return res.send('添加采购人失败');
    }
    res.send('采购人添加成功');
  });
});

app.post('/add_user', (req, res) => {
  const { name, department, contact } = req.body;
  const query = `INSERT INTO users (name, department, contact) VALUES (?, ?, ?)`;
  db.query(query, [name, department, contact], (err, result) => {
    if (err) {
      return res.send('添加领用人失败');
    }
    res.send('领用人添加成功');
  });
});

app.post('/add_purchase_date', (req, res) => {
  const { date, username } = req.body;
  const query = `INSERT INTO purchase_dates (date, username) VALUES (?, ?)`;
  db.query(query, [date, username], (err, result) => {
    if (err) {
      return res.send('添加采购日期失败');
    }
    res.send('采购日期添加成功');
  });
});

app.post('/add_inventory_date', (req, res) => {
  const { date, username } = req.body;
  const query = `INSERT INTO inventory_dates (date, username) VALUES (?, ?)`;
  db.query(query, [date, username], (err, result) => {
    if (err) {
      return res.send('添加入库日期失败');
    }
    res.send('入库日期添加成功');
  });
});

// 耗材管理功能
app.post('/use_material', (req, res) => {
  const { search } = req.body;
  const query = `SELECT * FROM materials WHERE name LIKE '%${search}%' OR specifications LIKE '%${search}%' OR brand LIKE '%${search}%' OR check_by LIKE '%${search}%' OR remarks LIKE '%${search}%'`;
  db.query(query, (err, result) => {
    if (err) {
      return res.send('查询失败');
    }
    res.json(result);
  });
});

app.post('/scrap_material', (req, res) => {
  const { search } = req.body;
  const query = `SELECT * FROM scrapped_materials WHERE name LIKE '%${search}%' OR specifications LIKE '%${search}%' OR brand LIKE '%${search}%' OR check_by LIKE '%${search}%' OR remarks LIKE '%${search}%'`;
  db.query(query, (err, result) => {
    if (err) {
      return res.send('查询失败');
    }
    res.json(result);
  });
});

app.post('/inventory_check', (req, res) => {
  const { search } = req.body;
  const query = `SELECT * FROM materials WHERE name LIKE '%${search}%' OR specifications LIKE '%${search}%' OR brand LIKE '%${search}%' OR check_by LIKE '%${search}%' OR remarks LIKE '%${search}%'`;
  db.query(query, (err, result) => {
    if (err) {
      return res.send('查询失败');
    }
    res.json(result);
  });
});

app.post('/add_inventory', (req, res) => {
  const { batch, category, name, quantity } = req.body;
  const query = `INSERT INTO materials (batch, category, name, quantity) VALUES (?, ?, ?, ?)`;
  db.query(query, [batch, category, name, quantity], (err, result) => {
    if (err) {
      return res.send('入库失败');
    }
    res.send('入库成功');
  });
});

// 启动服务器
app.listen(PORT, () => {
  console.log(`服务器已启动，访问地址 http://localhost:${PORT}`);
});
