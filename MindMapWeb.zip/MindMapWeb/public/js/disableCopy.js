// public/js/disableCopy.js

// 禁止鼠标右键
document.addEventListener('contextmenu', function (e) {
  e.preventDefault();
}, false);

// 禁止复制
document.addEventListener('copy', function (e) {
  e.preventDefault();
  alert('复制功能已禁用！');
}, false);

// 禁止文本选中
document.addEventListener('selectstart', function (e) {
  e.preventDefault();
}, false);

// 禁止拖拽
document.addEventListener('dragstart', function (e) {
  e.preventDefault();
}, false);
